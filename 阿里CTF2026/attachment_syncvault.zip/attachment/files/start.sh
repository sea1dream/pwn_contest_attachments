#!/bin/bash
while true; do /app/pwn ; sleep 1; done