#!/bin/sh
while true; do
    echo "Running healthchecks..."
    /app/bin/filechecker > /dev/null 2>&1
    /app/bin/networkchecker > /dev/null 2>&1
    sleep 60
done
