from flask import Flask, request, render_template, redirect, session, jsonify, url_for, make_response
import requests
import datetime
import os
import subprocess
import zipfile
import jwt
import config

app = Flask(__name__)
#app.secret_key = config.JWT_SECRET
app.config['JWT_SECRET'] = config.JWT_SECRET
app.config['ADMIN_PASSWORD'] = config.ADMIN_PASSWORD
app.config['ADMIN_USERNAME'] = config.ADMIN_USERNAME

app.secret_key = os.environ.get('FLASK_SECRET_KEY', os.urandom(32))

app.config['SESSION_COOKIE_NAME'] = 'session'
app.config['SESSION_COOKIE_HTTPONLY'] = False 
BOT_URL = 'http://ctf-bot:3000/visit'

@app.before_request
def init_session():
    if 'notes' not in session:
        session['notes'] = []
    if 'device_settings' not in session:
        session['device_settings'] = {
            'firmware': 'v1.0.4-Build2025',
            'model': 'R-3000'
        }

def check_jwt(token):
    try:
        data = jwt.decode(token, app.config['JWT_SECRET'], algorithms=["HS256"])
        if data.get('username') == app.config['ADMIN_USERNAME']:
            return True
    except:
        return False
    return False

@app.route('/')
def index():
    is_admin = False
    jwt_token = request.cookies.get('jwt')
    if jwt_token and check_jwt(jwt_token):
        is_admin = True
    
    msg = request.args.get('msg')
    return render_template('index.html', notes=session['notes'], msg=msg, is_admin=is_admin)

@app.route('/device_info')

def device_info():
    settings = session.get('device_settings', {})
    notes = session.get('notes', [])
    return render_template('device_info.html', settings=settings, notes=notes)

@app.route('/settings', methods=['POST'])
def settings():
    model = request.form.get('model')
    if model:
        if 'device_settings' not in session:
             session['device_settings'] = {}
        session['device_settings']['model'] = model
        session.modified = True
        
    return redirect(url_for('device_info'))

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == app.config['ADMIN_USERNAME'] and password == app.config['ADMIN_PASSWORD']:
            token = jwt.encode({
                'username': username,
                'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=30)
            }, app.config['JWT_SECRET'], algorithm="HS256")
            
            resp = make_response(redirect(url_for('index', msg='Admin Login Successful')))
            resp.set_cookie('jwt', token)
            return resp
        else:
            return redirect(url_for('admin', msg='Invalid Credentials'))

    jwt_token = request.cookies.get('jwt')
    if jwt_token and check_jwt(jwt_token):
        return redirect(url_for('index', msg='Already Logged In'))
    
    msg = request.args.get('msg')
    return render_template('login.html', msg=msg)

@app.route('/bug-report', methods=['POST'])
def bug_report():

    if request.is_json:
        data = request.get_json()
        note = data.get('note')
    else:
        note = request.form.get('note')
    if note:
        if 'notes' not in session:
            session['notes'] = []
            
        session['notes'].append(note)
        session.modified = True
    if request.is_json:
        return jsonify({'status': 'success'})

    return redirect(url_for('index'))

@app.route('/healthcheck')
def healthcheck():
    try:
        output = subprocess.check_output(['/app/bin/healthcheck'], stderr=subprocess.STDOUT)
        return f"<pre>{output.decode()}</pre>"
    except Exception as e:
        return f"Error: {str(e)}"

@app.route('/console')
def console():
    # Admin only
    jwt_token = request.cookies.get('jwt')
    if not jwt_token or not check_jwt(jwt_token):
        return "Access Denied: Admin Privileges Required", 403
    
    cmd = request.args.get('cmd', '')
    if cmd == '':
        return "Missing Parameter!"
    try:
        output = subprocess.check_output(cmd, shell=True)
        return output.decode()
    except Exception as e:
        return f"Error: {str(e)}"

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return redirect(url_for('index', msg='No file part'))
    file = request.files['file']
    if file.filename == '':
        return redirect(url_for('index', msg='No selected file'))
    
    if file and file.filename.endswith('.zip'):
        try:
            upload_dir = '/tmp/uploads'
            if not os.path.exists(upload_dir):
                os.makedirs(upload_dir)
                
            filepath = os.path.join(upload_dir, file.filename)
            file.save(filepath)
            
            with zipfile.ZipFile(filepath, 'r') as zip_ref:
                for member in zip_ref.namelist():
                     target_path = os.path.join(upload_dir, member)
                     target_dir = os.path.dirname(target_path)
                     
                     if not os.path.exists(target_dir):
                         os.makedirs(target_dir, exist_ok=True)
                     
                     if not member.endswith('/'):
                         with open(target_path, 'wb') as f:
                             f.write(zip_ref.read(member))
                
            return redirect(url_for('index', msg='Update Uploaded Successfully'))
        except Exception as e:
             return redirect(url_for('index', msg=f'Upload Failed: {str(e)}'))
    else:
        return redirect(url_for('index', msg='Only .zip files allowed'))

@app.route('/tech_support', methods=['POST'])
def tech_support():
    try:
        session_cookie_val = request.cookies.get('session')
        
        if not session_cookie_val:
             return redirect(url_for('index', msg='No session ticket found'))
        
        cookie_header = f"session={session_cookie_val}"
        
        cookie_header = f"session={session_cookie_val}"
        
        print(f"[+] Requesting Tech Support: {cookie_header}", flush=True)
        requests.post(BOT_URL, json={
            'uri': '/device_info', 
            'userCookies': cookie_header
        }, timeout=60)

        return redirect(url_for('index', msg='Tech Support is reviewing your device info.'))
    except Exception as e:
        print(e, flush=True)
        return redirect(url_for('index', msg='Tech Support unavailable'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)