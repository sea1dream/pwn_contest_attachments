import secrets
import os

JWT_SECRET = secrets.token_hex(64)
ADMIN_PASSWORD = "REDACTED"
ADMIN_USERNAME = 'admin'
