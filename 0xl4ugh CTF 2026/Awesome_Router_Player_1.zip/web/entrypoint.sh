#!/bin/sh
set -e

# Start background script (non-blocking)
/app/background.sh &

echo "$FLAG" >> /root/flag.txt
chmod 600 /root/flag.txt
exec supervisord -c /etc/supervisor/conf.d/supervisord.conf
