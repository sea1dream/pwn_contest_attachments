const express = require('express');
const puppeteer = require('puppeteer');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
let adminPassword = "REDACTED";


app.post('/visit', async (req, res) => {
    const { uri, userCookies } = req.body;
    const origin = process.env.APP_URL || 'http://web:5000';
    console.log(`[BOT] Received visit request for: ${uri}`);

    const browser = await puppeteer.launch({
        headless: 'new',
        args: [
            '--no-sandbox',
            '--disable-dev-shm-usage',
            '--disable-gpu',
            '--disable-setuid-sandbox'
        ],
        executablePath: '/usr/bin/google-chrome'
    });

    const page = await browser.newPage();

    try {
        console.log('[BOT] Authenticating as Admin...');
        await page.goto(`${origin}/admin`, { waitUntil: 'networkidle0' });

        await page.type('input[name="username"]', 'admin');
        await page.type('input[name="password"]', adminPassword);

        await Promise.all([
            page.waitForNavigation({ waitUntil: 'networkidle0' }),
            page.click('button[type="submit"]')
        ]);

        console.log('[BOT] Admin logged in.');


        if (userCookies) {
            console.log(`[BOT] Adding user cookies: ${userCookies}`);
            const cookies = userCookies.split(';').map(pair => {
                const [name, value] = pair.trim().split('=');
                return { name, value, domain: 'web', path: '/' };
            });
            await page.setCookie(...cookies);
        }

        console.log(`[BOT] Navigating to ${origin}${uri}`);
        await page.goto(origin + uri, {
            waitUntil: 'networkidle0',
            timeout: 5000
        });

        console.log('[BOT] Page loaded successfully.');
        res.json({ success: true, message: 'Tech Support visited the page.' });

    } catch (err) {
        console.error('[BOT] Error visiting page:', err.message);
        res.status(500).json({ error: 'Bot failed', details: err.message });
    } finally {
        await browser.close();
    }
});

app.listen(PORT, "0.0.0.0", () => {
    console.log(`Bot server running on port ${PORT}`);
});