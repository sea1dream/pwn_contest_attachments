sudo docker build -t rsync .
sudo docker run -it -p 8730:8730 rsync
