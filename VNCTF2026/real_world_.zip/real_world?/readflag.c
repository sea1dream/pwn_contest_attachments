#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    setuid(0);
    setgid(0);

    FILE *f = fopen("/flag", "r");
    if (!f) {
        perror("fopen");
        return 1;
    }

    char buf[256];
    fgets(buf, sizeof(buf), f);
    fclose(f);

    puts(buf);
    return 0;
}
