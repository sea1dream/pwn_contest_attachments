#!/bin/sh

# Get the user
user=$(ls /home)

# Check the environment variables for the flag and assign to INSERT_FLAG
if [ "$A1CTF_FLAG" ]; then
    INSERT_FLAG="$A1CTF_FLAG"
    unset A1CTF_FLAG
elif [ "$SHCTF_FLAG" ]; then
    INSERT_FLAG="$SHCTF_FLAG"
    unset SHCTF_FLAG
elif [ "$GZCTF_FLAG" ]; then
    INSERT_FLAG="$GZCTF_FLAG"
    unset GZCTF_FLAG
elif [ "$FLAG" ]; then
    INSERT_FLAG="$FLAG"
    unset FLAG
else
    INSERT_FLAG="SHCTF{fake_flag}"
fi

# 将FLAG写入文件 请根据需要修改
echo $INSERT_FLAG | tee /home/$user/flag

# 赋予程序运行权限
# chmod 711 /home/ctf/vuln
# chmod 711 /home/ctf/libc-2.31.so
# chmod 711 /home/ctf/ld-2.31.so

/etc/init.d/xinetd start;
sleep infinity;
