#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/sha.h>

typedef struct {
    int id, heal, atkBoost, defBoost, energyBoost;
    char name[32];
} Item;

#define MAX_WAREHOUSE 24

typedef struct {
    int hp, maxHp, atk, def, energy;
    int warehouseCount;
    Item warehouse[MAX_WAREHOUSE];
} Player;

typedef struct {
    const char *name;
    int hp, atk, def, boss;
} Enemy;

typedef struct {
    unsigned char nonce[16];
    int32_t stage;
    Player player;
} SavePayload;

#define LEN(a) ((int)(sizeof(a) / sizeof((a)[0])))
#define SAVE_CODE_MAX 4096

static const char *PLAYER_NAME = "Misaka Mikoto";

static const unsigned char IV[16] = {'T', 'o', 'a', 'r', 'u', 'R', 'a', 'i',
                                     'l', 'g', 'u', 'n', '2', '0', '2', '6'};

static const Item ITEM_POOL[] = {{201, 35, 0, 0, 0, "Recovery Patch"},
                                 {202, 0, 2, 0, 0, "Attack Script"},
                                 {203, 0, 0, 2, 0, "Defense Script"},
                                 {204, 0, 0, 0, 2, "Energy Cell"}};

static const Enemy ENEMIES[] = {
    {"Runaway Security Robot", 48, 11, 3, 0},
    {"AIM Rampage Esper", 64, 13, 4, 0},
    {"Kiyama Network Phantom", 82, 15, 5, 0},
    {"Level Upper Beast Core (BOSS)", 120, 18, 6, 1}};

static int read_line(char *s, size_t n) {
    if (!fgets(s, (int)n, stdin))
        return 0;
    s[strcspn(s, "\r\n")] = 0;
    return 1;
}

static int in_range(int x, int a, int b) { return x >= a && x <= b; }

static int read_choice(int a, int b) {
    char buf[64];
    int x;
    for (;;) {
        printf("> ");
        if (!fgets(buf, sizeof(buf), stdin))
            continue;
        if (sscanf(buf, "%d", &x) == 1 && in_range(x, a, b))
            return x;
        printf("Choose %d-%d.\n", a, b);
    }
}

static int dmg(int x) { return x < 1 ? 1 : x; }

static void init_player(Player *p) {
    memset(p, 0, sizeof(*p));
    p->hp = p->maxHp = 100;
    p->atk = 12;
    p->def = 3;
    p->energy = 1;
}

static void warehouse_add(Player *p, Item it) {
    if (p->warehouseCount >= MAX_WAREHOUSE)
        return;
    p->warehouse[p->warehouseCount++] = it;
    printf("Obtained item: %s\n", it.name);
}

static void apply_item(Player *p, Item it) {
    p->hp += it.heal;
    if (p->hp > p->maxHp)
        p->hp = p->maxHp;
    p->atk += it.atkBoost;
    p->def += it.defBoost;
    p->energy += it.energyBoost;
}

static int use_item_from_warehouse(Player *p, int allowDrop) {
    if (p->warehouseCount <= 0) {
        puts("Warehouse is empty.");
        return 0;
    }
    for (;;) {
        puts("\n--- Warehouse ---");
        for (int i = 0; i < p->warehouseCount; i++)
            printf("%d) %s (HP+%d ATK+%d DEF+%d EN+%d)\n", i + 1,
                   p->warehouse[i].name, p->warehouse[i].heal,
                   p->warehouse[i].atkBoost, p->warehouse[i].defBoost,
                   p->warehouse[i].energyBoost);
        printf("%d) Back\n", p->warehouseCount + 1);

        int c = read_choice(1, p->warehouseCount + 1);
        if (c == p->warehouseCount + 1)
            return 0;

        int idx = c - 1;
        if (!in_range(idx, 0, p->warehouseCount - 1)) {
            puts("Invalid item index.");
            continue;
        }
        if (!allowDrop) {
            Item it = p->warehouse[idx];
            for (int i = idx; i < p->warehouseCount - 1; i++)
                p->warehouse[i] = p->warehouse[i + 1];
            p->warehouseCount--;
            apply_item(p, it);
            printf("Used %s\n", it.name);
            return 1;
        }

        puts("1) Use  2) Drop  3) Swap  4) Back");
        c = read_choice(1, 4);
        if (c == 4)
            continue;

        if (c == 3) {
            if (p->warehouseCount < 2) {
                puts("Need at least 2 items to swap.");
                continue;
            }
            printf("Swap with item index (1-%d):\n", p->warehouseCount);
            int idx2 = read_choice(1, p->warehouseCount) - 1;
            if (!in_range(idx2, 0, p->warehouseCount - 1)) {
                puts("Invalid swap target index.");
                continue;
            }
            if (idx2 == idx) {
                puts("Same item selected, no change.");
                continue;
            }
            Item tmp = p->warehouse[idx];
            p->warehouse[idx] = p->warehouse[idx2];
            p->warehouse[idx2] = tmp;
            printf("Swapped positions: %d <-> %d\n", idx + 1, idx2 + 1);
            continue;
        }

        Item it = p->warehouse[idx];
        for (int i = idx; i < p->warehouseCount - 1; i++)
            p->warehouse[i] = p->warehouse[i + 1];
        p->warehouseCount--;

        if (c == 1) {
            apply_item(p, it);
            printf("Used %s\n", it.name);
        } else {
            printf("Dropped %s\n", it.name);
        }

        if (p->warehouseCount <= 0) {
            puts("Warehouse is now empty.");
            return 0;
        }
    }
}

static int load_key(unsigned char key[32]) {
    FILE *fp = fopen("flag", "rb");
    unsigned char buf[1024];
    size_t n, total = 0;
    unsigned int out = 0;
    EVP_MD_CTX *ctx;
    if (!fp)
        return 0;
    ctx = EVP_MD_CTX_new();
    if (!ctx) {
        fclose(fp);
        return 0;
    }
    if (EVP_DigestInit_ex(ctx, EVP_sha256(), NULL) != 1) {
        EVP_MD_CTX_free(ctx);
        fclose(fp);
        return 0;
    }
    while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) {
        total += n;
        if (EVP_DigestUpdate(ctx, buf, n) != 1) {
            EVP_MD_CTX_free(ctx);
            fclose(fp);
            return 0;
        }
    }
    fclose(fp);
    if (!total) {
        EVP_MD_CTX_free(ctx);
        return 0;
    }
    if (EVP_DigestFinal_ex(ctx, key, &out) != 1 || out != 32) {
        EVP_MD_CTX_free(ctx);
        return 0;
    }
    EVP_MD_CTX_free(ctx);
    return 1;
}

static int aes_enc(const unsigned char *in, int inLen,
                   const unsigned char key[32], unsigned char **out,
                   int *outLen) {
    EVP_CIPHER_CTX *c = EVP_CIPHER_CTX_new();
    int n1, n2;
    *out = NULL;
    *outLen = 0;
    if (!c)
        return 0;
    *out = (unsigned char *)malloc((size_t)inLen + EVP_MAX_BLOCK_LENGTH);
    if (!*out) {
        EVP_CIPHER_CTX_free(c);
        return 0;
    }
    if (EVP_EncryptInit_ex(c, EVP_aes_256_cbc(), NULL, key, IV) != 1 ||
        EVP_EncryptUpdate(c, *out, &n1, in, inLen) != 1 ||
        EVP_EncryptFinal_ex(c, *out + n1, &n2) != 1) {
        EVP_CIPHER_CTX_free(c);
        free(*out);
        *out = NULL;
        return 0;
    }
    *outLen = n1 + n2;
    EVP_CIPHER_CTX_free(c);
    return 1;
}

static int aes_dec(const unsigned char *in, int inLen,
                   const unsigned char key[32], unsigned char **out,
                   int *outLen) {
    EVP_CIPHER_CTX *c = EVP_CIPHER_CTX_new();
    int n1, n2;
    *out = NULL;
    *outLen = 0;
    if (!c)
        return 0;
    *out = (unsigned char *)malloc((size_t)inLen + 1);
    if (!*out) {
        EVP_CIPHER_CTX_free(c);
        return 0;
    }
    if (EVP_DecryptInit_ex(c, EVP_aes_256_cbc(), NULL, key, IV) != 1 ||
        EVP_DecryptUpdate(c, *out, &n1, in, inLen) != 1 ||
        EVP_DecryptFinal_ex(c, *out + n1, &n2) != 1) {
        EVP_CIPHER_CTX_free(c);
        free(*out);
        *out = NULL;
        return 0;
    }
    *outLen = n1 + n2;
    EVP_CIPHER_CTX_free(c);
    return 1;
}

static char *b64_enc(const unsigned char *in, int inLen) {
    int n = 4 * ((inLen + 2) / 3);
    char *out = (char *)malloc((size_t)n + 1);
    if (!out)
        return NULL;
    if (EVP_EncodeBlock((unsigned char *)out, in, inLen) < 0) {
        free(out);
        return NULL;
    }
    out[n] = 0;
    return out;
}

static int b64_dec(const char *s, unsigned char **out, int *outLen) {
    char *c = (char *)malloc(strlen(s) + 1);
    int i, j = 0, n, pad = 0;
    *out = NULL;
    *outLen = 0;
    if (!c)
        return 0;
    for (i = 0; s[i]; i++)
        if (s[i] != ' ' && s[i] != '\t' && s[i] != '\r' && s[i] != '\n')
            c[j++] = s[i];
    c[j] = 0;
    if (j == 0 || (j % 4)) {
        free(c);
        return 0;
    }
    *out = (unsigned char *)malloc((size_t)(j * 3 / 4 + 1));
    if (!*out) {
        free(c);
        return 0;
    }
    n = EVP_DecodeBlock(*out, (unsigned char *)c, j);
    if (n < 0) {
        free(c);
        free(*out);
        *out = NULL;
        return 0;
    }
    if (c[j - 1] == '=')
        pad++;
    if (c[j - 2] == '=')
        pad++;
    *outLen = n - pad;
    free(c);
    return 1;
}

static void drop_random_item(Player *p) {
    warehouse_add(p, ITEM_POOL[rand() % LEN(ITEM_POOL)]);
}

static int save_export(const Player *p, int stage,
                       const unsigned char key[32]) {
    unsigned char hash[SHA256_DIGEST_LENGTH], *cipher = NULL, *pkg = NULL;
    unsigned int h = 0;
    int cLen = 0, pkgLen = 0, ok = 0;
    char *code = NULL;
    SavePayload sp = {0};
    if (RAND_bytes(sp.nonce, sizeof(sp.nonce)) != 1) {
        puts("Save export failed.");
        return 0;
    }
    sp.stage = stage;
    sp.player = *p;
    do {
        if (EVP_Digest(&sp, sizeof(sp), hash, &h, EVP_sha256(), NULL) != 1 ||
            h != SHA256_DIGEST_LENGTH)
            break;
        if (!aes_enc((const unsigned char *)&sp, sizeof(sp), key, &cipher,
                     &cLen))
            break;
        pkgLen = SHA256_DIGEST_LENGTH + cLen;
        pkg = (unsigned char *)malloc((size_t)pkgLen);
        if (!pkg)
            break;
        memcpy(pkg, hash, SHA256_DIGEST_LENGTH);
        memcpy(pkg + SHA256_DIGEST_LENGTH, cipher, (size_t)cLen);
        code = b64_enc(pkg, pkgLen);
        if (!code)
            break;
        printf("\n=== SAVE CODE BEGIN ===\n%s\n=== SAVE CODE END ===\n\n",
               code);
        ok = 1;
    } while (0);
    free(cipher);
    free(pkg);
    free(code);
    if (!ok)
        puts("Save export failed.");
    return ok;
}

static int save_import(Player *p, int *stage, const char *code,
                       const unsigned char key[32]) {
    unsigned char hash[SHA256_DIGEST_LENGTH], *pkg = NULL, *plain = NULL;
    unsigned int h = 0;
    int pkgLen = 0, cLen, plainLen = 0, ok = 0;
    do {
        if (!b64_dec(code, &pkg, &pkgLen))
            break;
        if (pkgLen <= SHA256_DIGEST_LENGTH)
            break;
        cLen = pkgLen - SHA256_DIGEST_LENGTH;
        if (!aes_dec(pkg + SHA256_DIGEST_LENGTH, cLen, key, &plain, &plainLen))
            break;
        if (plainLen != (int)sizeof(SavePayload))
            break;
        if (EVP_Digest(plain, plainLen, hash, &h, EVP_sha256(), NULL) != 1 ||
            h != SHA256_DIGEST_LENGTH)
            break;
        if (memcmp(pkg, hash, SHA256_DIGEST_LENGTH) != 0)
            break;
        {
            SavePayload sp;
            memcpy(&sp, plain, sizeof(sp));
            *p = sp.player;
            *stage = sp.stage;
        }
        ok = 1;
    } while (0);
    free(pkg);
    free(plain);
    if (!ok)
        puts("Save import failed.");
    return ok;
}

static void show_status(const Player *p) {
    printf("\n%s HP %d/%d  ATK %d DEF %d  Energy %d\n", PLAYER_NAME, p->hp,
           p->maxHp, p->atk, p->def, p->energy);
    printf("Warehouse: %d\n\n", p->warehouseCount);
}

static int prep(Player *p, int stage, const unsigned char key[32]) {
    for (;;) {
        puts("1) Status 2) Warehouse 3) Save 4) Go");
        int c = read_choice(1, 4);
        if (c == 1)
            show_status(p);
        else if (c == 2) {
            use_item_from_warehouse(p, 1);
            puts("");
        } else if (c == 3) {
            if (save_export(p, stage, key)) {
                puts("Back to main menu.");
                return 1;
            }
            continue;
        } else
            return 0;
    }
}

static const char *INTENTS[] = {"Quick Strike", "Power Smash", "Guard Break"};

static int fight(Player *p, const Enemy *src) {
    Enemy e = *src;
    printf("\nEnemy: %s%s\n", e.name, e.boss ? " [BOSS]" : "");
    while (p->hp > 0 && e.hp > 0) {
        int intent = rand() % 3;
        int fullDefend = 0;
        const char *intentText = INTENTS[intent];
        printf("YOU: HP %d/%d ATK %d DEF %d EN %d WH %d\n"
               "ENEMY: HP %d ATK %d DEF %d / Intent: %s\n"
               "------------------------------------------\n"
               "1)Atk 2)Def 3)Railgun 4)Use Item 5)Retreat\n",
               p->hp, p->maxHp, p->atk, p->def, p->energy, p->warehouseCount,
               e.hp, e.atk, e.def, intentText);
        int c = read_choice(1, 5);
        if (c == 1) {
            int d = dmg(p->atk + (rand() % 5) - e.def / 2);
            e.hp -= d;
            p->energy++;
            printf("YOU: Attack dealt %d damage.\n", d);
        } else if (c == 2) {
            fullDefend = 1;
            puts("YOU: Def stance activated.");
        } else if (c == 3) {
            if (p->energy < 2) {
                puts("YOU: Not enough energy for Railgun.");
                puts("");
                continue;
            }
            p->energy -= 2;
            int d = dmg(p->atk * 2 + (rand() % 10) - e.def / 3);
            e.hp -= d;
            printf("YOU: Railgun dealt %d damage.\n", d);
        } else if (c == 4) {
            int hp0 = p->hp;
            int atk0 = p->atk;
            int def0 = p->def;
            int en0 = p->energy;
            if (!use_item_from_warehouse(p, 0)) {
                puts("YOU: No item used.");
            } else
                printf("YOU: Item used (HP %+d, ATK %+d, DEF %+d, EN %+d).\n",
                       p->hp - hp0, p->atk - atk0, p->def - def0,
                       p->energy - en0);
        } else {
            if (e.boss)
                puts("YOU: Cannot retreat from boss.");
            else if (rand() % 100 < 45) {
                puts("YOU: Retreat succeeded.");
                puts("");
                return 2;
            } else
                puts("YOU: Retreat failed.");
        }
        if (e.hp <= 0) {
            puts("ENEMY: Defeated.");
            if (!e.boss)
                drop_random_item(p);
            puts("");
            return 1;
        }

        int enemyDmg;
        if (intent == 0) {
            enemyDmg = dmg(e.atk + (rand() % 4) - p->def);
            printf("ENEMY: Quick strike dealt %d damage.\n", enemyDmg);
        } else if (intent == 1) {
            enemyDmg = dmg(e.atk + 5 + (rand() % 6) - p->def);
            printf("ENEMY: Power smash dealt %d damage.\n", enemyDmg);
        } else {
            enemyDmg = dmg(e.atk + 2 + (rand() % 4) - p->def / 2);
            printf("ENEMY: Guard break dealt %d damage.\n", enemyDmg);
        }

        if (fullDefend) {
            int reduced = dmg((enemyDmg + 2) / 3);
            printf("YOU: Def reduced damage %d -> %d.\n", enemyDmg, reduced);
            enemyDmg = reduced;
        }

        p->hp -= enemyDmg;
        puts("");
    }
    return p->hp > 0 ? 1 : 0;
}

void inits() {
    setvbuf(stdin, 0, _IONBF, 0);
    setvbuf(stdout, 0, _IONBF, 0);
    setvbuf(stderr, 0, _IONBF, 0);
}

int main(void) {
    inits();

    struct {
        char buf[SAVE_CODE_MAX];
        unsigned char key[32];
        Player p;
    } state;

    srand((unsigned int)time(NULL));
    puts("Academy City: Railgun Patrol");

    if (!load_key(state.key)) {
        puts("Failed to read railgun.key");
        return 1;
    }

    for (;;) {
        int i, start = 0;
        int backToMenu = 0;

        for (;;) {
            puts("1) New  2) Load");
            if (read_choice(1, 2) == 1) {
                init_player(&state.p);
                break;
            }
            puts("\n=== SAVE CODE BEGIN ===");
            if (!read_line(state.buf, sizeof(state.buf)) || !state.buf[0])
                continue;
            puts("=== SAVE CODE END ===");
            if (save_import(&state.p, &start, state.buf, state.key)) {
                if (start < 0 || start >= LEN(ENEMIES))
                    start = 0;
                break;
            }
        }

        printf("\nWelcome, %s\n", PLAYER_NAME);
        for (i = start; i < LEN(ENEMIES); i++) {
            int r;
            printf("\n-- Zone %d: %s --\n", i + 1, ENEMIES[i].name);
            if (prep(&state.p, i, state.key)) {
                backToMenu = 1;
                break;
            }
            r = fight(&state.p, &ENEMIES[i]);
            if (r == 0) {
                puts("Mission failed.");
                return 0;
            }
            if (r == 2) {
                i--;
                puts("Retreated.");
            }
        }

        if (backToMenu)
            continue;

        puts("\nMission complete!");
        show_status(&state.p);
        return 0;
    }

    return 0;
}
