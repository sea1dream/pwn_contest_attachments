#include <fcntl.h>
#include <seccomp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <asm/prctl.h>
#include <unistd.h>

void read_all(int fd, void *buf, size_t count) {
    size_t total = 0;
    char *ptr = (char *)buf;
    while (total < count) {
        ssize_t n = read(fd, ptr + total, count - total);
        if (n <= 0)
            break;
        total += n;
    }
}

void inits() {
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
}

void setup_seccomp() {
    scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_ALLOW);
    seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(execve), 0);
    seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(execveat), 0);
    if (seccomp_load(ctx) < 0) {
        perror("seccomp_load");
        exit(-1);
    }
}

void run(void *addr) {
    syscall(SYS_arch_prctl, ARCH_SET_FS, 0);
    syscall(SYS_arch_prctl, ARCH_SET_GS, 0);
    __asm__ volatile("mov %0, %%rax\n\t"
                     "xor %%rbx, %%rbx\n\t"
                     "xor %%rcx, %%rcx\n\t"
                     "xor %%rdx, %%rdx\n\t"
                     "xor %%rsi, %%rsi\n\t"
                     "xor %%rdi, %%rdi\n\t"
                     "xor %%rbp, %%rbp\n\t"
                     "xor %%rsp, %%rsp\n\t"
                     "xor %%r8, %%r8\n\t"
                     "xor %%r9, %%r9\n\t"
                     "xor %%r10, %%r10\n\t"
                     "xor %%r11, %%r11\n\t"
                     "xor %%r12, %%r12\n\t"
                     "xor %%r13, %%r13\n\t"
                     "xor %%r14, %%r14\n\t"
                     "xor %%r15, %%r15\n\t"
                     "jmp *%%rax\n\t" ::"r"(addr));
}

void *mmap_random(size_t length) {
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0) {
        perror("open");
        exit(-1);
    }

    unsigned long addr = 0;
    read_all(fd, &addr, sizeof(addr));
    close(fd);

    addr &= 0x00007FFFFFFFF000ULL;
    if (!addr)
        exit(-1);

    void *base = mmap((void *)addr, length, PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (base == MAP_FAILED) {
        perror("mmap");
        exit(-1);
    }

    return base;
}

int main() {
    inits();
    puts("\nW4terCTF 2026 / Predator\n");
    printf("Length: ");

    unsigned int len = 0;
    if (scanf("%u", &len) != 1 || len > 0x1000) {
        puts("Invalid length");
        return 0;
    }

    void *base = mmap_random(0x1000);

    printf("Payload: ");
    read_all(0, base, len);

    setup_seccomp();
    run(base);

    return 0;
}