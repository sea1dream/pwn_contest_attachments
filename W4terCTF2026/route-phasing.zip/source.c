#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

static int send_all(int fd, const void *buf, size_t len) {
    size_t sent = 0;
    while (sent < len) {
        ssize_t n = send(fd, (const char *)buf + sent, len - sent, 0);
        if (n <= 0) {
            if (n < 0 && errno == EINTR)
                continue;
            return -1;
        }
        sent += (size_t)n;
    }
    return 0;
}

static void send_simple_response(int client_fd, int code, const char *reason,
                                 const char *body) {
    char header[512];
    int body_len = strlen(body);
    int n = snprintf(header, sizeof(header),
                     "HTTP/1.1 %d %s\r\n"
                     "Content-Type: text/plain; charset=utf-8\r\n"
                     "Content-Length: %d\r\n"
                     "Connection: close\r\n\r\n",
                     code, reason, body_len);
    if (n > 0 && n < sizeof(header)) {
        send_all(client_fd, header, n);
        send_all(client_fd, body, body_len);
    }
}

static void handle_client(int client_fd) {
    char req[8192];
    ssize_t nread = recv(client_fd, req, sizeof(req) - 1, 0);
    if (nread <= 0) {
        return;
    }
    req[nread] = '\0';

    char method[512] = {0}, uri[1024] = {0}, version[512] = {0};
    if (sscanf(req, "%511s %1023s %511s", method, uri, version) != 3 ||
        uri[0] != '/') {
        send_simple_response(client_fd, 400, "Bad Request",
                             "bad/invalid request\n");
        return;
    }

    if (strcmp(method, "GET") != 0) {
        send_simple_response(client_fd, 405, "Method Not Allowed",
                             "only GET is supported\n");
        return;
    }

    char *query = strchr(uri, '?');
    char *ptok = strstr(uri, "..");

    if (ptok && (!query || ptok < query)) {
        send_simple_response(client_fd, 403, "Forbidden", "forbidden\n");
        return;
    }

    char fs_path[NAME_MAX] = ".";

    if (query) {
        strncpy(fs_path + 1, uri, query - uri);
    } else {
        strcpy(fs_path + 1, uri);
    }

    if (fs_path[strlen(fs_path) - 1] == '/') {
        strcat(fs_path, "index.html");
    }

    int file_fd = open(fs_path, O_RDONLY);
    if (file_fd < 0) {
        send_simple_response(client_fd, 404, "Not Found", "not found\n");
        return;
    }

    struct stat st;
    if (fstat(file_fd, &st) != 0 || !S_ISREG(st.st_mode)) {
        close(file_fd);
        send_simple_response(client_fd, 404, "Not Found", "not found\n");
        return;
    }

    char header[512];
    int hlen = snprintf(header, sizeof(header),
                        "HTTP/1.1 200 OK\r\n"
                        "Content-Type: text/html; charset=utf-8\r\n"
                        "Content-Length: %lld\r\n"
                        "Connection: close\r\n\r\n",
                        (long long)st.st_size);
    if (hlen <= 0 || hlen >= sizeof(header) ||
        send_all(client_fd, header, hlen) != 0) {
        close(file_fd);
        if (hlen <= 0 || hlen >= sizeof(header))
            send_simple_response(client_fd, 500, "Internal Server Error",
                                 "internal error\n");
        return;
    }

    char buf[4096];
    ssize_t rn;
    while ((rn = read(file_fd, buf, sizeof(buf))) > 0 ||
           (rn < 0 && errno == EINTR)) {
        if (rn > 0 && send_all(client_fd, buf, (size_t)rn) != 0) {
            break;
        }
    }

    close(file_fd);
}

int main(int argc, char **argv) {
    signal(SIGCHLD, SIG_IGN);
    int port = argc >= 2 ? atoi(argv[1]) : 8080;
    if (port <= 0 || port > 65535) {
        fprintf(stderr, "invalid port: %s\n", argv[1]);
        return 1;
    }

    if (chdir("html") != 0) {
        perror("chdir html");
        return 1;
    }

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("socket");
        return 1;
    }

    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) !=
        0) {
        perror("setsockopt");
        close(server_fd);
        return 1;
    }

    struct sockaddr_in addr = {.sin_family = AF_INET,
                               .sin_addr.s_addr = htonl(INADDR_ANY),
                               .sin_port = htons((unsigned short)port)};

    if (bind(server_fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        perror("bind");
        close(server_fd);
        return 1;
    }

    if (listen(server_fd, 16) != 0) {
        perror("listen");
        close(server_fd);
        return 1;
    }

    fprintf(stdout, "w4ter httpd listening on 0.0.0.0:%d\n", port);
    fprintf(stdout, "serving: ./html/*\n");

    while (1) {
        int client_fd = accept(server_fd, NULL, NULL);
        if (client_fd < 0) {
            if (errno == EINTR) {
                continue;
            }
            perror("accept");
            break;
        }

        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            close(client_fd);
            continue;
        }

        if (pid == 0) {
            close(server_fd);
            handle_client(client_fd);
            close(client_fd);
            exit(0);
        }

        close(client_fd);
    }

    close(server_fd);
    return 0;
}
