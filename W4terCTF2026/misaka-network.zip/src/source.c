#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    uint32_t owner;
    uint32_t uid;

    char *uname;
    char *upass;
    uint32_t uname_sz;
    uint32_t upass_sz;
} user_t;

typedef struct {
    uint32_t owner;
    char *filename;
    void *data;
    size_t size;
    uint32_t filename_sz;
} file_t;

static user_t **users;
static size_t user_cnt;
static size_t user_cap;
static uint32_t next_uid = 1001;
static user_t *current_user;

static file_t **files;
static size_t file_cnt;
static size_t file_cap;

static void chomp(char *s) {
    if (s == NULL) {
        return;
    }

    size_t len = strlen(s);
    if (len > 0 && s[len - 1] == '\n') {
        s[len - 1] = '\0';
    }
}

static char *read_line(const char *prompt) {
    if (prompt != NULL) {
        fputs(prompt, stdout);
        fflush(stdout);
    }

    char *line = NULL;
    size_t cap = 0;
    if (getline(&line, &cap, stdin) < 0) {
        free(line);
        return NULL;
    }

    chomp(line);
    return line;
}

static user_t *find_user_by_name(const char *uname) {
    for (size_t i = 0; i < user_cnt; i++) {
        if (users[i] != NULL && strcmp(users[i]->uname, uname) == 0) {
            return users[i];
        }
    }

    return NULL;
}

static file_t *find_file(const char *filename) {
    for (size_t i = 0; i < file_cnt; i++) {
        if (files[i] != NULL && strcmp(files[i]->filename, filename) == 0) {
            return files[i];
        }
    }

    return NULL;
}

static int grow_users() {
    if (user_cnt < user_cap) {
        return 0;
    }

    size_t new_cap = user_cap == 0 ? 8 : user_cap * 2;
    user_t **new_users = realloc(users, new_cap * sizeof(*new_users));
    if (new_users == NULL) {
        puts("error: out of memory");
        return -1;
    }

    users = new_users;
    user_cap = new_cap;
    return 0;
}

static int grow_files() {
    if (file_cnt < file_cap) {
        return 0;
    }

    size_t new_cap = file_cap == 0 ? 8 : file_cap * 2;
    file_t **new_files = realloc(files, new_cap * sizeof(*new_files));
    if (new_files == NULL) {
        puts("error: out of memory");
        return -1;
    }

    files = new_files;
    file_cap = new_cap;
    return 0;
}

static user_t *create_user(uint32_t owner, uint32_t uid, char *uname,
                           char *upass) {
    if (grow_users() != 0) {
        return NULL;
    }

    user_t *user = calloc(1, sizeof(*user));
    if (user == NULL) {
        puts("error: out of memory");
        return NULL;
    }

    user->owner = owner;
    user->uid = uid;
    user->uname = uname;
    user->upass = upass;
    user->uname_sz = strlen(uname);
    user->upass_sz = upass == NULL ? 0 : strlen(upass);

    users[user_cnt++] = user;
    return user;
}

static file_t *create_file(uint32_t owner, char *filename, size_t size) {
    if (grow_files() != 0) {
        return NULL;
    }

    file_t *file = calloc(1, sizeof(*file));
    if (file == NULL) {
        puts("error: out of memory");
        return NULL;
    }

    file->data = calloc(1, size);
    if (size != 0 && file->data == NULL) {
        free(file);
        puts("error: out of memory");
        return NULL;
    }

    file->owner = owner;
    file->filename = filename;
    file->size = size;
    file->filename_sz = strlen(filename);

    files[file_cnt++] = file;
    return file;
}

static user_t *create_login_user(uint32_t owner, char *uname, char *upass) {
    if (uname == NULL || upass == NULL || *uname == '\0' || *upass == '\0') {
        return NULL;
    }

    user_t *user = create_user(owner, next_uid, uname, upass);
    if (user != NULL) {
        next_uid++;
    }

    return user;
}

static void free_user(user_t *user) {
    if (user == NULL) {
        return;
    }

    free(user->uname);
    free(user->upass);
    free(user);
}

static void free_file(file_t *file) {
    if (file == NULL) {
        return;
    }

    free(file->filename);
    free(file->data);
    free(file);
}

static void cmd_id() {
    printf("uid=%u(%s) owner=%u\n", current_user->uid, current_user->uname,
           current_user->owner);
}

static void cmd_shell() {
    if (current_user->uid != 0) {
        puts("permission denied");
        return;
    }

    system("/bin/sh");
}

static void cmd_useradd(char *uname, char *upass) {
    if (uname == NULL || upass == NULL || *uname == '\0' || *upass == '\0') {
        puts("usage: useradd <uname> <upass>");
        return;
    }
    if (find_user_by_name(uname) != NULL) {
        puts("user exists");
        return;
    }

    user_t *user =
        create_login_user(current_user->uid, strdup(uname), strdup(upass));
    if (user == NULL) {
        return;
    }

    printf("created uid=%u\n", user->uid);
}

static void cmd_touch(char *filename, char *size_s) {
    if (filename == NULL || size_s == NULL || *filename == '\0' ||
        *size_s == '\0') {
        puts("usage: touch <filename> <size>");
        return;
    }

    errno = 0;
    char *end = NULL;
    unsigned long long raw_size = strtoull(size_s, &end, 10);
    if (errno == ERANGE || *end != '\0' || raw_size > SIZE_MAX) {
        puts("invalid size");
        return;
    }

    file_t *file = find_file(filename);
    if (file != NULL) {
        puts("file exists");
        return;
    }

    file = create_file(current_user->uid, strdup(filename), (size_t)raw_size);
    if (file == NULL) {
        return;
    }

    printf("created %s size=%zu\n", file->filename, file->size);
}

static void cmd_rm(char *filename) {
    if (filename == NULL || *filename == '\0') {
        puts("usage: rm <filename>");
        return;
    }

    for (size_t i = 0; i < file_cnt; i++) {
        if (files[i] != NULL && strcmp(files[i]->filename, filename) == 0) {
            if (files[i]->owner != current_user->uid) {
                puts("permission denied");
                return;
            }
            free_file(files[i]);
            files[i] = files[file_cnt - 1];
            files[file_cnt - 1] = NULL;
            file_cnt--;
            puts("removed");
            return;
        }
    }

    puts("no such file");
}

static void cmd_ls() {
    for (size_t i = 0; i < file_cnt; i++) {
        if (files[i] != NULL) {
            printf("%s owner=%u size=%zu\n", files[i]->filename,
                   files[i]->owner, files[i]->size);
        }
    }
}

static void cmd_userdel(char *uname) {
    if (uname == NULL || *uname == '\0') {
        puts("usage: userdel <uname>");
        return;
    }

    user_t *user = find_user_by_name(uname);
    if (user == NULL) {
        puts("no such user");
        return;
    }
    if (user->uid == 0) {
        puts("cannot delete root");
        return;
    }
    if (user == current_user) {
        puts("cannot delete self");
        return;
    }
    if (user->owner != current_user->uid) {
        puts("permission denied");
        return;
    }

    for (size_t i = 0; i < user_cnt; i++) {
        if (users[i] == user) {
            free_user(users[i]);
            users[i] = users[user_cnt - 1];
            users[user_cnt - 1] = NULL;
            user_cnt--;
            puts("deleted");
            return;
        }
    }

    puts("no such user");
}

static void cmd_su(char *uname) {
    if (uname == NULL || *uname == '\0') {
        puts("usage: su <uname>");
        return;
    }

    user_t *user = find_user_by_name(uname);
    if (user == NULL) {
        puts("no such user");
        return;
    }
    if (user->upass == NULL) {
        puts("login disabled");
        return;
    }

    char *pass = read_line("Password: ");
    if (pass == NULL) {
        return;
    }

    if (strcmp(pass, user->upass) != 0) {
        puts("authentication failure");
        free(pass);
        return;
    }

    current_user = user;
    free(pass);
}

static void dispatch(char *line) {
    char *dup = strdup(line);

    char *cmd = strtok(dup, " \t");
    if (cmd == NULL) {
        free(dup);
        return;
    }

    char *arg1 = strtok(NULL, " \t");
    char *arg2 = strtok(NULL, " \t");

    if (strcmp(cmd, "id") == 0) {
        cmd_id();
    } else if (strcmp(cmd, "shell") == 0) {
        cmd_shell();
    } else if (strcmp(cmd, "useradd") == 0) {
        cmd_useradd(arg1, arg2);
    } else if (strcmp(cmd, "userdel") == 0) {
        cmd_userdel(arg1);
    } else if (strcmp(cmd, "su") == 0) {
        cmd_su(arg1);
    } else if (strcmp(cmd, "touch") == 0) {
        cmd_touch(arg1, arg2);
    } else if (strcmp(cmd, "rm") == 0) {
        cmd_rm(arg1);
    } else if (strcmp(cmd, "ls") == 0) {
        cmd_ls();
    } else {
        puts("unknown command");
    }

    free(dup);
}

static int init_users() {
    user_t *root = create_user(0, 0, strdup("root"), NULL);
    current_user = create_user(0, 1000, strdup("misaka"), strdup("misaka"));
    if (root == NULL || current_user == NULL) {
        return -1;
    }

    return 0;
}

int main() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);

    if (init_users() != 0) {
        return 1;
    }

    puts("\nMisaka Network\n > CONNECTED.\n");

    char cmdline[4096];
    while (1) {
        printf("%s $ ", current_user->uname);
        fflush(stdout);

        if (fgets(cmdline, sizeof(cmdline), stdin) == NULL) {
            break;
        }

        chomp(cmdline);
        dispatch(cmdline);
    }

    return 0;
}
