#!/bin/sh
echo -n "$GZCTF_FLAG" > /home/ctf/flag
unset GZCTF_FLAG
chown ctf:ctf /home/ctf/flag

ulimit -d 131072

socat -T60 TCP-LISTEN:70,reuseaddr,fork EXEC:"chroot /home/ctf chroot --userspec=1000\:1000 / ./pwn",stderr
