#include <seccomp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct {
    char table[128];
} w4_ctx;

#define SWAP_U8(a, b)                                                          \
    do {                                                                       \
        char tmp = (a);                                                        \
        (a) = (b);                                                             \
        (b) = tmp;                                                             \
    } while (0)

void w4_init(char *key, size_t sz, w4_ctx *ctx) {
    char expand[128] = {};
    for (int i = 0; i < 128; ++i) {
        expand[i] = key[i % sz];
        ctx->table[i] = i;
    }
    for (int i = 0; i < 128; ++i) {
        SWAP_U8(ctx->table[i], ctx->table[(i + expand[i]) % 128]);
    }
}

void w4_encrypt(char *data, size_t sz, w4_ctx *ctx) {
    for (int i = 0; i < sz; ++i) {
        data[i] ^= ctx->table[i % 128];
    }
}

void inits() {
    setvbuf(stdin, 0, _IONBF, 0);
    setvbuf(stdout, 0, _IONBF, 0);
    setvbuf(stderr, 0, _IONBF, 0);

    scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_ALLOW);
    seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(execve), 0);
    seccomp_rule_add(ctx, SCMP_ACT_KILL, SCMP_SYS(execveat), 0);
    if (seccomp_load(ctx) < 0) {
        perror("seccomp_load");
        exit(-1);
    }
}

#define BUF_SZ 128

int main() {
    inits();

    char *buf = malloc(BUF_SZ);
    w4_ctx ctx = {};

    puts("\nW4terCTF 2026 / Replace\n");

    printf("Key: ");
    fgets(buf, BUF_SZ, stdin);
    w4_init(buf, BUF_SZ, &ctx);

    printf("\nData: ");
    fgets(buf, BUF_SZ, stdin);
    w4_encrypt(buf, BUF_SZ, &ctx);

    puts("\nDone.");
    _exit(0);
}